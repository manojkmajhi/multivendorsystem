# All Strawhats - Production Deployment

## Quick Deploy

1. **Install dependencies:**
   ```bash
   npm install --production
   ```

2. **Configure environment:**
   - Copy `.env.production` to `.env`
   - Update with your actual credentials

3. **Start server:**
   ```bash
   npm start
   ```

## Performance Features

✅ Gzip compression enabled
✅ Static asset caching (365 days)
✅ Security headers configured
✅ Production optimizations active
✅ Image lazy loading
✅ Minified responses

## Server Requirements

- Node.js >= 16.0.0
- npm >= 8.0.0
- 512MB RAM minimum
- 1GB disk space

## Environment Variables

See `.env.production` for all configuration options.

## Support

For issues, check server logs and ensure all environment variables are set correctly.
